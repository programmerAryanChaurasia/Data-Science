from flask import Flask, request, render_template
import pickle
import pandas as pd
import numpy as np

app = Flask(__name__)

# Load the combined preprocessor and linear regression model
with open('LinearRegressionModel.pkl', 'rb') as f:
    model = pickle.load(f)

#dataset
df=pd.read_csv('Cleaned_Car_data.csv')


@app.route('/')
def home():
    car_name=df['name'].unique()
    #company=df['company'].unique()
    year=df['year'].unique()
    fuel_type=df['fuel_type'].unique()
    return render_template('index.html',car_name=car_name,year=year,fuel_type=fuel_type)

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        name = request.form['name']
        # company = request.form['company']
        year = request.form['year']
        kms_driven = request.form['kms_driven']
        fuel_type = request.form['fuel_type']

        print("Name==",name,year,kms_driven,fuel_type)

        # Validate inputs
        # company
        if not all([name, year, kms_driven, fuel_type]):
            return render_template('error.html', message='Please fill in all fields.')
        
        try:
            year = int(year)
            kms_driven = int(kms_driven)
        except ValueError:
            return render_template('error.html', message='Year and Kms Driven must be valid numbers.')

        car_comp=name.split(" ")[0]
        print("Name company==",car_comp)
        # Create a DataFrame for the input
        input_data = pd.DataFrame([[name,car_comp,year,kms_driven,fuel_type]], 
                                  columns=['name', 'company', 'year', 'kms_driven', 'fuel_type'])
        
        # Preprocess the input data and make prediction
        prediction = model.predict(input_data)
        
        return render_template('result.html', prediction=prediction[0])

if __name__ == '__main__':
    app.run(debug=True)
